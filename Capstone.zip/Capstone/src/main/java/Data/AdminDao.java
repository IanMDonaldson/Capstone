package Data;

public interface AdminDao {
    public boolean adminExists(Admin admin);
}
