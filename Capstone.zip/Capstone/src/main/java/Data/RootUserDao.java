package Data;

public interface RootUserDao {
}
