<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
  Created by IntelliJ IDEA.
  User: dragomundo
  Date: 11/29/20
  Time: 7:29 PM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="topSideNav.jsp" %>
<html>
<head>
    <title>Department Continuous Improvement Application</title>
   <style>
        .main {
            position: relative;
            display: -webkit-inline-flex; /_Chrome_/
            display: inline-flex;
            -webkit-flex-direction: column; /_Chrome_/

        }
        #studentDiv {
            position: fixed;
            width: 15%;
            overflow-y: scroll;
            overflow-x: hidden;
            max-height: 80%;
            -webkit-flex-direction: row;
            flex-direction: row;
        }
        #studentListDiv {
            position: absolute;
        }
        #courseDiv {
            position: relative;
            margin-left: 45%;
            margin-top: 20%;
        }
        #submitDiv {
            position: relative;
            margin-left: 77%;
            padding-top: 3%;
        }

        h1 {
            padding-top: 4%;
            padding-left: 20%;
            float:top;
            overflow-wrap: normal;
        }




   </style>
</head>
<body>
<h1><b>Please select all students that are taking your Course to enroll them into your roster.</b></h1>
<!--todo finish this shit-->
<div class="main">
    <form method="post" action="InstructorServlet?action=assocStudentsPOST">
        <div id="studentDiv">
            <c:forEach items="${sessionScope.students}" var="student">
                <div id="studentListDiv">
                    <label for="studentbox" id="studentlabel" class="studentlabel">${student.studentLname}, ${student.studentFname}</label>

                    <input type="checkbox" id="studentbox"name="student" value="${student.studentId}">
                </div>
                <br>
            </c:forEach>
        </div>
        <div id="courseDiv">
            <label for="courseSelect"></label>
            <select id="courseSelect">
                <c:forEach items="${sessionScope.courses}" var="course">
                    <option id="courses" value="${course.courseID}"><b>${course.department} ${course.courseNumber}</b> - ${course.courseTitle}</option>
                </c:forEach>
            </select>
        </div>
        <div id="submitDiv">
            <input name="submit" type="submit" value="Enroll Students to Course">
        </div>
    </form>
</div>
</body>
</html>
