google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

//calling java fuction to get database info
//dummy data

var swpData=[2.95,3.5,3.2,2.75];
var swpName=["SWP1","SWP2","SWP3","SWP4"];
var rawList='<%= Session["rawSOData"].ToString() %>';
//select for term
function fillSelectData(target, data){

    for(var i = 0; i < data.length; i++) {
        var opt = document.createElement('option');
        opt.innerHTML = data[i];
        opt.value = data[i];
        target.appendChild(opt);
    }
}
function ready() {
    var selectTerm = document.getElementById("terms");
    var termData = [];

    var selectCourse = document.getElementById("courses");
    var coursesData=[];

    var selectData = document.getElementById("chartfucntions");
    var dataOutput=["Raw", "Mean","Median"];

    fillSelectData(selectTerm,termData);
    fillSelectData(selectCourse,coursesData);
    fillSelectData(selectData,dataOutput);

}
document.addEventListener("DOMContentLoaded", ready);



function drawChart() {
    var data = google.visualization.arrayToDataTable([
        ['SO','SO1','SO2','SO3','SO4','SO5','SO6'],
        [1,  1000,      400,0,0,0,0],
        [2,  1170,      460,0,0,0,0],
        [3,  660,       1120,0,0,0,0],
        [4,  1030,      540,0,0,0,0]
    ]);

    var options = {
        title: 'Student Work Product',
        curveType: 'function',
        legend: { position: 'bottom' }
    };

    var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

    chart.draw(data, options);
}