package web;

import javax.servlet.http.HttpServlet;

public class RootServlet extends HttpServlet {
    //get to list of public users
}
