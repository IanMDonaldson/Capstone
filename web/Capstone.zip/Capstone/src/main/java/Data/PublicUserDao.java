package Data;

public interface PublicUserDao {
}
