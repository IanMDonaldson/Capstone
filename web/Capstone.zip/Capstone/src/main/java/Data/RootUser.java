package Data;

public class RootUser {
}
